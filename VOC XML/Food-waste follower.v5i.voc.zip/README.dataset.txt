# Food-waste follower > 2025-12-07 11:15pm
https://universe.roboflow.com/foodwaste-detection/food-waste-follower-zig4a

Provided by a Roboflow user
License: CC BY 4.0

